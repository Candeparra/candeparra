#include<stdio.h>

void swap(int *a , int *b){
	int aux = 0;
	aux = *a;
	*a = *b;
	*b = aux;
}

int main(void){
	int x;
	int y;
	x = 6;
	y = 4;
	printf("el valor de x es %d\n.El valor de y es %d\n",x,y);
	swap(&x,&y);
	printf("el valor de x es %d\n.El valor de y es %d\n",x,y);

}