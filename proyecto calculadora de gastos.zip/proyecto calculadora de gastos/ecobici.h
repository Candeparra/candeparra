#include <stdio.h>

float ecobici(float *ptrsueldo, int *ptracuecobici){
	int viaje;
	if(*ptrsueldo < 200){
		printf("No tienes saldo suficiente para usar la ecobici\n");

	}else {
		*ptrsueldo-=200;
		*ptracuecobici+=1;
		printf("ya se desconto un viaje\n Quieres descontar otro?\n");
		printf("1)Si \n 2)No \n");
		scanf("%d",&viaje);
		switch(viaje){
			case 1:
			if(*ptrsueldo < 200){
				printf("No tienes saldo suficiente para usar la ecobici\n");
			}else{
				*ptrsueldo-=200;
				*ptracuecobici+=1;
				printf("ya se desconto otro viaje\n");
			}break;
			case 2:
			printf("Gracias por viajar en ecobici\n");
			break;
		default:
			printf("No es un caso valido\n");
			break;

		}
	}

	return *ptrsueldo;

}