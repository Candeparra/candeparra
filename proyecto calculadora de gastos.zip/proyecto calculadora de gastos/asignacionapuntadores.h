 ptracumetro = &acumetro;
 ptracucolectivo = &acucolectivo;
 ptracuecobici = &acuecobici;
 ptracugasolina = &acugasolina;
 ptracutren = &acutren;
 ptracutrolebus = &acutrolebus;
 ptrgastogasolina = &gastogasolina;
 ptrsueldo = &sueldo;