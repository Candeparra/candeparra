#include<stdio.h>
#include<stdbool.h>

#include"metro.h"
#include"colectivo.h"
#include"ecobici.h"
#include"trolebus.h"
#include"tren.h"
#include"gasolina.h"