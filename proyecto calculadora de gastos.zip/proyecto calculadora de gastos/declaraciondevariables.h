#include <stdio.h>

char direccion[]="/home/candeparra/proyecto calculadora de gastos/gastos.txt";
 FILE *arch, *fd;

 float sueldo = 0;
 int gastos = 0;
 bool hola = true;
 char letra, caracter, fecha[30];

 int acumetro = 0;
 int acucolectivo = 0;
 int acuecobici = 0;
 int acugasolina = 0;
 int acutren = 0;
 int acutrolebus = 0;

 float gastogasolina = 0;

 int *ptracumetro;
 int *ptracucolectivo;
 int *ptracuecobici;
 int *ptracugasolina;
 int *ptracutren;
 int *ptracutrolebus;
 float *ptrgastogasolina;
 float *ptrsueldo;
