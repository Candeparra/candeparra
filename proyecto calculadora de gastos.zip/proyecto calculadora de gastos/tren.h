#include <stdio.h>

float tren(float *ptrsueldo, int *ptracutren){
	int viaje;
	if(*ptrsueldo < 650){
		printf("No tienes saldo suficiente para usar el tren\n");

	}else {
		*ptrsueldo-=650;
		*ptracutren+=1;
		printf("ya se desconto un viaje\n Quieres descontar otro?\n");
		printf("1)Si \n 2)No \n");
		scanf("%d",&viaje);
		switch(viaje){
			case 1:
			if(*ptrsueldo < 650){
				printf("No tienes saldo suficiente para usar el tren\n");
			}else{
				*ptrsueldo-=650;
				*ptracutren+=1;
				printf("ya se desconto otro viaje\n");
			}break;
			case 2:
			printf("Gracias por viajar en tren\n");
			break;
		default:
			printf("No es un caso valido\n");
			break;

		}
	}
	return *ptrsueldo;

}