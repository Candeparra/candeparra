#include <stdio.h>


float gasolina(float *ptrsueldo, int *ptracugasolina, float *ptrgastogasolina){
	float gasto = 0;
	printf("Inserta el gasto en gasolina\n");
	scanf("%f", &gasto);
	if(gasto > *ptrsueldo){
		printf("No puedes gastar esa cantidas de gasolina\n");

	}else{
		*ptrsueldo = *ptrsueldo - gasto;
		*ptrgastogasolina = *ptrgastogasolina - gasto;
		*ptracugasolina -=1;
	}

	printf("Gracias por viajar en coche\n");
	return *ptrsueldo;

}