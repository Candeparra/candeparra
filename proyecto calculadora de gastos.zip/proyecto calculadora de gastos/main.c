#include "librerias.h"
#include "declaraciondevariables.h"


int main() {


#include "asignacionapuntadores.h"


	printf("****Bienvenido a tu calculadora de gastos****\n\n");
	printf("Ingrese su sueldo mensual:");
	scanf("%f",&sueldo);

	printf("\n Que desea hacer?\n");

	while(hola){
		printf("\n\n 1)Entrar al metro\n 2)usar el colectivo");
		printf("\n 3)Rentar una ecobici\n 4)Subir al trolebus\n 5)subir al tren");
		printf("\n 6)Cargar gasolina\n 7)Ver instruciones 8) Ver gastos");
		printf("\n 9) Imprimir gastos en archivo txt");
		printf(" 10) Salir del programa\n Opcion:  ");


		scanf("%d", &gastos);
		scanf("%c", &letra);

		if(letra){
			printf("\n\n");
		}

		#include "casoprincipal.h"
	} 

	return 0;
}
