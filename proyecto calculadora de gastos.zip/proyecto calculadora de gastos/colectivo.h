#include <stdio.h>

float colectivo(float *ptrsueldo, int *ptracucolectivo){
	int viaje;
	if(*ptrsueldo < 800){
		printf("No tienes saldo suficiente para usar el clectivo\n");

	}else {
		*ptrsueldo-=800;
		*ptracucolectivo+=1;
		printf("ya se desconto un viaje\n Quieres descontar otro?\n");
		printf("1)Si \n 2)No \n");
		scanf("%d",&viaje);
		switch(viaje) {
			case 1:
			if(*ptrsueldo < 800){
				printf("No tienes saldo suficiente para usar el colectivo\n");
			}else{
				*ptrsueldo-=800;
				*ptracucolectivo+=1;
				printf("ya se desconto otro viaje\n");
			}break;
			case 2:
			printf("Gracias por viajar en colectivo\n");
			break;
		default:
			printf("No es un caso valido\n");
			break;

		}
	}
	return *ptrsueldo;

}