switch(gastos) {

case 1:
	printf("Seleccionaste metro\n\n");
	metro(ptrsueldo, ptracumetro);
	printf("Tu sueldo actual es %0.2f\n\n Que mas te gustaria hacer?\n", *ptrsueldo);
	break;
case 2:
	printf("Seleccionaste colectivo\n\n");
	colectivo(ptrsueldo, ptracucolectivo);
	printf("Tu sueldo actual es %0.2f\n\n Que mas te gustaria hacer?\n", *ptrsueldo);
	break;
case 3:
	printf("Seleccionaste ecobici\n\n");
	ecobici(ptrsueldo, ptracumetro);
	printf("Tu sueldo actual es %0.2f\n\n Que mas te gustaria hacer?\n", *ptrsueldo);
	break;
case 4:
	printf("Seleccionaste trolebus\n\n");
	tren(ptrsueldo, ptracutrolebus);
	printf("Tu sueldo actual es %0.2f\n\n Que mas te gustaria hacer?\n", *ptrsueldo);
	break;
case 5:
	printf("Seleccionaste tren\n\n");
	trolebus(ptrsueldo, ptracutren);
	printf("Tu sueldo actual es %0.2f\n\n Que mas te gustaria hacer?\n", *ptrsueldo);
	break;
case 6:
	printf("Seleccionaste cargar gasolina\n\n");
	gasolina(ptrsueldo, ptracugasolina, ptrgastogasolina);
	printf("Tu sueldo actual es %0.2f\n\n Que mas te gustaria hacer?\n", *ptrsueldo);
	break;
case 7:
	printf("Seleccionaste ver instrucciones\n\n");
	arch = fopen("instrucciones.txt", "r+");

	if (arch==NULL){
		printf("Error al abrir el archivo\n");
		return -1;
	} while((caracter = fgetc(arch))!= EOF){
		printf("%s", &caracter);
	}fclose(arch);
	break;
case 8:
	printf("Servicio\tViajes\t\tMonto gastado\n");
	printf("Metro\t\t%d\t\t%d\n",*ptracumetro, (*ptracumetro*250));
	printf("Colectivo\t%d\t\t%d\n",*ptracucolectivo, (*ptracucolectivo*800));
	printf("Ecobici\t\t%d\t\t%d\n",*ptracuecobici, (*ptracuecobici*200));
	printf("Trolebus\t%d\t\t%d\n",*ptracutrolebus, (*ptracutrolebus*700));
	printf("Tren\t\t%d\t\t%d\n",*ptracutren, (*ptracutren*650));
	printf("Gasolina\t%d\t\t%0.2f\n",*ptracugasolina, *ptrgastogasolina);
	printf("\nSu sueldo restante es : %0.2f\n\n", *ptrsueldo);
	break;
case 9:
	fd = fopen(direccion, "at");
	if (fd==NULL){
		printf("Error al crear el archivo\n");
		break;
	}
	printf("Escribe la fecha:\n");
    fgets(fecha, sizeof(fecha), stdin);
	

	printf("El archivo de texto ha sido creado/actualizado\n");
	printf("Con el nombre de Gastos.txt\n");

	fprintf(fd,"Fecha %s",fecha);
	fprintf(fd,"Servicio\tViajes\t\t Monto gastado\n");
	fprintf(fd,"Metro\t\t%d\t\t%d\n",*ptracumetro, (*ptracumetro*250));
	fprintf(fd,"Colectivo\t%d\t\t%d\n",*ptracucolectivo, (*ptracucolectivo*800));
	fprintf(fd,"Ecobici\t%d\t\t%d\n",*ptracuecobici, (*ptracuecobici*200));
	fprintf(fd,"Trolebus\t%d\t\t%d\n",*ptracutrolebus, (*ptracutrolebus*700));
	fprintf(fd,"Tren\t\t%d\t\t%d\n",*ptracutren, (*ptracutren*650));
	fprintf(fd,"Gasolina\t%d\t\t%0.2f\n",*ptracugasolina, *ptrgastogasolina);
	fprintf(fd,"\nSu sueldo restante es : %0.2f\n\n\n\n", *ptrsueldo);
	fclose(fd);
	break;
case 10:
		printf("Gracias por usar el programa :)\n");
		hola = false;
		break;
default: 
		printf("Ese no es un caso valido\n\n");
		break;

	}

