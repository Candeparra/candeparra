#include <stdlib.h>
#include <stdio.h>

void array_swap(int *x, int *y) {
 int swap = *x;
 *x = *y;
 *y = swap;

}

int main(void) {
    int x=6, y=4;
    printf("El valor de x es %d\n y el valor de y es %d\n",x,y);
    array_swap(&x,&y);
    printf("El valor de x es %d\n y el valor de y es %d\n",x,y);
    return EXIT_SUCCESS;
}
 
