#include <stdlib.h>
#include <stdio.h>

void absolute(int x, int y) {
 if(x>=0){
    x = y ;   
} else {
    y = -x ;
}
}

int main(void) {
    int a=0, res=0;
    a = -10;
    absolute(a,res);
    printf("%d\n", res);
    return EXIT_SUCCESS;
}

/*Si tomamos la definición del algorítmo con el lenguaje del teórico, 
  el valor que se imprime por pantalla es 10. En C, el valor que se muestra por pantalla es 0 (valor original de res), por que los parámetros se pasan por valor no por referencia.*/