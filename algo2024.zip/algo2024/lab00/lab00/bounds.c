#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

#define ARRAY_SIZE 4

struct bound_data {
    bool is_upperbound;
    bool is_lowerbound;
    bool exists;
    unsigned int where;
};

struct bound_data check_bound(int value, int arr[], unsigned int length) {
    struct bound_data res;
    res.is_upperbound = true;
    res.is_lowerbound = true;
    res.exists = false;
    res.where = 0;


    for(unsigned int i=0; i<length;i++){

        res.is_lowerbound = res.is_lowerbound && (value <= arr[i]);
        res.is_upperbound = res.is_upperbound && (value >= arr[i]);
        if ( arr[i] == value){
            res.exists = true ;
            res.where = i;
        }

    } 

    return res;
}

int main(void) {

    int a[ARRAY_SIZE] = {0, -1, 9, 4};
    int value=9;
    
    for(int i=0 ; i<ARRAY_SIZE ; i++){
        printf("\n Ingrese el elemento de la posicion %d\n", i );
        scanf("%d",&a[i]);
    } 


    printf("\n Ingrese un numero entero\n");
    scanf("%d", &value);
    


    struct bound_data result = check_bound(value, a, ARRAY_SIZE);

    printf("\n%d\n", result.is_upperbound); // Imprime 1
    printf("%d\n", result.is_lowerbound); // Imprime 0
    printf("%u\n", result.exists);        // Imprime 1
    printf("%u\n", result.where);         // Imprime 2

    return EXIT_SUCCESS;
}

