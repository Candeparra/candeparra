#ifndef MYBOOL_H
#define MYBOOL_H



#define true 1
#define false 0

typedef int mybool;

#endif