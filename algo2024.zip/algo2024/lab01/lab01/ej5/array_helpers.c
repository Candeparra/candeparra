#include "array_helpers.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "mybool.h"

unsigned int array_from_file(int array[],
   unsigned int max_size,
   const char *filepath) {
    FILE* file = fopen(filepath,"r");
    if (file==NULL){
        printf("Error al abrir el archivo\n");
        exit(EXIT_FAILURE);
    }
    unsigned int length = 0;
    if(!feof(file)){
        fscanf(file,"%u",&length);
        assert(max_size>= length);
        for(unsigned int i=0 ; i< length && !feof(file); i++){
            fscanf(file, "%d", &array[i]);
        }
    }

    fclose(file);
    return length;
}

void array_dump(int a[], unsigned int length) {
    if(length > 0){
        printf("[");
        for (unsigned int i=0;i<length-1;i++){
            printf("%d,",a[i]);
        }
        printf("%d]\n",a[length-1]);
    }
}

mybool array_is_sorted(int a[], unsigned int length){
    mybool res= true;
    for(unsigned int i=0; i<length-1;i++){
      res= res && a[i] <= a[i+1];

  }
  return res;
} 