#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include <stdbool.h>
#include "stack.h"

    
typedef struct _s_stack {
    stack_elem e;
    struct _s_stack *next;
} stack_t;

stack stack_empty(stack s) {
    return s = NULL;
}

// Función para añadir un elemento al tope de la pila
stack stack_push(stack s, stack_elem e) {
      stack_t *p = (stack_t *)malloc(sizeof(stack_t));
      if (p == NULL){
          return s;
      }
      p->e=e;
      p-> next=s;
      return p;
}


// Función para eliminar el elemento del tope de la pila
stack stack_pop(stack s) {
      assert(!stack_is_empty(s));
      stack_t *t = s;
      s = s->next;
      free(t);
      return s;
}
    

// Función para obtener el tamaño de la pila
unsigned int stack_size(stack s) {
	int l = 0;
    while (!stack_is_empty(s)){ 
        s = s->next;
        l++;
    }
    return l;
  
}

// Función para comprobar si la pila está vacía
bool stack_is_empty(stack s) {
    return s == 0;
}

// Función para obtener el elemento en el tope de la pila
stack_elem stack_top(stack s) {
    assert(!stack_is_empty(s));
      return s-> e;
}

// Función para convertir la pila en un arreglo
stack_elem *stack_to_array(stack s) {
        unsigned int size = stack_size(s);
    stack_elem *result = (stack_elem *)malloc(size * sizeof(stack_elem));
    assert(!stack_is_empty(s));
        for (unsigned int i = 0; i < size; ++i) {
        result[i] = stack_top(s);
        s = stack_pop(s);
    }
     return result;
}
 
// Función para destruir la pila
stack stack_destroy(stack s) {
   while (!stack_is_empty(s)) {
        s = stack_pop(s);
    }
    return NULL;
}