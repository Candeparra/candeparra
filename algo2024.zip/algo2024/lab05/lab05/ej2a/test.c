#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "stack.h" 

void test_stack_pop_single_element() {
    // Crear una pila con un solo elemento
    stack s = stack_empty();
    stack_elem element = 10;
    s = stack_push(s, element);
    
    // Probar stack_pop con una pila de tamaño 1
    s = stack_pop(s);
    assert(stack_is_empty(s)); // La pila debe estar vacía después de la operación de stack_pop
    printf("stack_pop funciona correctamente para pilas de tamaño 1.\n");
}

void test_insert_after_empty_stack() {
    // Crear una pila vacía
    stack s = stack_empty();
    stack_elem new_element = 10;
    s = stack_push(s, new_element);
    
    // La pila no debe estar vacía después de insertar un elemento
    assert(!stack_is_empty(s));
    printf("Se pueden volver a insertar elementos después de vaciar la pila.\n");
}

void test_stack_to_array() {
    // Crear una pila con algunos elementos
    stack s = stack_empty();
    s = stack_push(s, 1);
    s = stack_push(s, 2);
    s = stack_push(s, 3);
    
    // Convertir la pila a un array
    stack_elem *array = stack_to_array(s);
    
    // Verificar si stack_to_array devuelve NULL para una pila vacía
    assert(array != NULL);
    printf("stack_to_array devuelve un array válido para una pila no vacía.\n");
    
    // Verificar si los elementos se devuelven en el orden correcto
    assert(array[0] == 3); // El elemento superior de la pila se convierte en el último elemento del array
    assert(array[1] == 2);
    assert(array[2] == 1);
    printf("stack_to_array devuelve los elementos en el orden correcto.\n");
    
    // Liberar la memoria asignada al array
    free(array);
}

int main() {
    // Ejecutar pruebas
    test_stack_pop_single_element();
    test_insert_after_empty_stack();
    test_stack_to_array();
    
    printf("Todas las pruebas pasaron con éxito.\n");
    
    return 0;
}

/*stack_pop funciona correctamente para pilas de tamaño 1.
Se pueden volver a insertar elementos después de vaciar la pila.
stack_to_array devuelve un array válido para una pila no vacía.
stack_to_array devuelve los elementos en el orden correcto.
Todas las pruebas pasaron con éxito.*/