#include<stdlib.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdio.h>

#include "strfuncs.h"


size_t string_length(const char *str){
unsigned int i = 0;
size_t length = 0;
while (str[i]!='\0'){
	length++;
    i++;
}
return length;
}


char *string_filter(const char *str, char c){
    unsigned int i = 0;
    unsigned int j = 0;
    size_t len = string_length(str);
    char *new_str = (char*)malloc(len+1);
    while (str[i] != '\0'){
        if(str[i] != c){
            new_str[j] = str[i];
            j++;
        }
        i++;
    };
    new_str[j] = '\0';
    return new_str;
}

bool string_is_symmetric(const char *str) {
    size_t length = string_length(str);
    
    for (size_t i = 0; i < length / 2; i++) {
        if (str[i] != str[length - 1 - i]) {
            return false; 
        }
    }
    return true; 
}