import sys
from zipfile import ZipFile
import pandas as pd
import sqlite3
from sqlite3 import Error
from os import remove

basededatos = 'coches_bd'

def precio_medio_por_marca(conexion):
	cursor = conexion.cursor()
	cursor.execute('SELECT marca, AVG(precio) FROM coches GROUP BY marca')
	datos = cursor.fetchall()
	return datos

def marca_coche_mas_barato(conexion):
	cursor = conexion.cursor()
	cursor.execute('SELECT marca, modelo, MIN(precio) FROM coches')
	datos = cursor.fetchall()
	return datos

def precio_total_coches(conexion):
	cursor = conexion.cursor()
	cursor.execute('SELECT SUM(precio) FROM coches')
	dato = cursor.fetchall()
	numero = dato[0][0]
	return numero

def numero_coches_tabla(conexion):
	cursor = conexion.cursor()
	cursor.execute('SELECT COUNT(*) FROM coches')
	dato = cursor.fetchall()
	numero = dato[0][0]
	return numero

def consultar_coches(conexion):
	cursor = conexion.cursor()
	cursor.execute('SELECT * FROM coches LIMIT 20')
	filas = cursor.fetchall()
	for fila in filas:
		print(fila)
def borrar_datos():
	try:
		remove(basededatos)
	except FileNotFoundError:
		pass

def insertar_tabla_coches(conexion, coche):
	cursor = conexion.cursor()
	cursor.execute('INSERT INTO coches(Marca, Modelo, Combustible, Transmision, Estado, Matriculacion, Kilometraje, Potencia, Precio) VALUES(?,?,?,?,?,?,?,?,?)',coche)
	conexion.commit()

def grabar_coche(conexion,datos):
	for fila in datos.itertuples():
		Marca = fila[1]
		Modelo = fila[2]
		Combustible = fila[3]
		Transmision = fila[4]
		Estado = fila[5]
		Matriculacion = fila[6]
		Kilometraje = fila[7]
		Potencia = fila [8]
		Precio = fila[9]

		coche = (Marca, Modelo, Combustible, Transmision, Estado, Matriculacion, Kilometraje, Potencia, Precio)
		insertar_tabla_coches(conexion, coche)

def crear_tabla_coches(conexion):
	cursor = conexion.cursor()
	cursor.execute('CREATE TABLE coches(Marca text, Modelo text, Combustible text, Transmision text, Estado text, Matriculacion text, Kilometraje integer, Potencia real, Precio real)')
	conexion.commit()

def crear_conexion_bd():
	try:
		conexion = sqlite3.connect(basededatos)
		return conexion 
	except Error:
	    print(Error)

def leer_datos(nombre):
	datos=pd.read_csv(nombre, sep=';')
	return datos

def descomprimir_fichero(nombre):
	with ZipFile(nombre,'r')as zip:
		zip.extractall()

if __name__ == '__main__':
	if len(sys.argv) != 2:
		print("Error. Numero de parametros incorrecto.Puede faltar el nombre del archivo")
	else:
		nombre_fichero = sys.argv[1]
		borrar_datos()
		descomprimir_fichero(nombre_fichero)
		datos = leer_datos(nombre_fichero)
		print(datos)
		conexion = crear_conexion_bd()
		crear_tabla_coches(conexion)
		grabar_coche(conexion,datos)
		print("\n Consultamos los datos de la tabla")
		consultar_coches(conexion)
		dato = numero_coches_tabla(conexion)
		print("\n El numero de coches es {}".format(dato))
		numero = precio_total_coches(conexion)
		dinero = '{:,}'.format(numero).replace(',','.')
		print("\n El precio total de coches es {}".format(dinero))
		datos = marca_coche_mas_barato(conexion)
		Marca = datos[0][0]
		Modelo = datos[0][1]
		Precio = datos[0][2]
		print("\n Coche mas barato. Marca: {}, Modelo: {}, precio:{}".format(Marca, Modelo, Precio))

		print("\n Precio medio por marca")
		datos = precio_medio_por_marca(conexion)
		for dato in datos:
			Marca = dato[0]
			Precio = dato[1]
			print(Marca,Precio)