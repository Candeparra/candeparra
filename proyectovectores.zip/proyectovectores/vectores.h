#ifndef PROYECTOVECTORES_VECTORES_H
#define PROYECTOVECTORES_VECTORES_H
#include <errno.h>
#include "funcionesvectores.h"


void vectores(){

   int cantidad = 0, opcion, opcionwhile = 1;
   printf("Programa que realiza operaciones con vectores de n dimensiones\n Dime de cuantas dimensiones seran los vectores\n");
   char input[10];

   if(errno == ERANGE){
      printf("Error:numero fuera del rango\n");
      exit(1);
   }else if(cantidad <= 0){
      printf("La cantidad debe ser mayor que cero\n");
      exit(1);
   }

   float *vector1 = (float*)calloc(cantidad,sizeof(float));
   float *vector2 = (float*)calloc(cantidad,sizeof(float));
   float *vectorresultante = (float*)calloc(cantidad, sizeof(float));

   llenarvectores(vector1,vector2,cantidad);


   do{

      printf("\n Que operacion te gustaria realizar con los vectores?\n");

      printf("0)Salir\n 1)suma\n 2)Resta\n 3)Producto por un escalar\n 4)Norma\n 5)Angulo entre dos vectores\n");
      if(fgets(input,10,stdin)==NULL){
         printf("Error: no se pudo leer la entrada\n");
         exit(1);
      }

      opcion = (int)strtol(input,NULL,10);
      if(opcion == 0){
         opcionwhile = opcion;
      }

      if(errno == ERANGE){
         printf("Error:numero fuera del rango\n");
         exit(1);
      }else if(opcion < 0 || opcion >5){
         printf("Numero fuera de rango\n");
         exit(1);
      }

      switch(opcion){
      case 0:
         printf("Gracias por usar el programa\n");
         break;
      case 1:
         printvectores(vector1, vector2, cantidad);
         printf("Seleccionaste la suma\n");
         sumavectores(vectorresultante, vector1, vector2,cantidad);
         break;
      case 2:
         printvectores(vector1, vector2, cantidad);
         printf("Seleccionaste resta\n");
         restavectores(vectorresultante, vector1, vector2, cantidad);
         break;
      case 3:
         printvectores(vector1, vector2, cantidad);
         printf("Seleccionaste producto por un escalar\n");
         productoporunescalar(vectorresultante, vector1, vector2, cantidad);
         break;
      case 4:

         printf("Seleccionaste Norma\n");
         normadelvector(vector1, vector2, cantidad);
         break; 
      case 5:
         printvectores(vector1, vector2, cantidad);
         printf("Selecionaste angulo entre dos vectores\n");
         angulovectores(vector1, vector2, cantidad);
         break;
      default:
         printf("Opcion no disponlible\n");
         break;
      }

   }while(opcionwhile!=0);

}



#endif // PROYECTOVECTORES_VECTORES_H












