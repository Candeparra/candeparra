#ifndef PROYECTOVECTORES_FUNCIONESVECTORES_H
#define PROYECTOVECTORES_FUNCIONESVECTORES_H
#include <stdio.h>
#include <stdlib.h>
#include <math.h> 
#include <errno.h>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

void llenarvectores(float *vector1,float *vector2,int cantidad){
	char input[10];
	for(int i=0; i<cantidad;++i){
		printf("Ingrese el valor del vector 1 en el indice [%d]\n",i+1);
		if(fgets(input,10,stdin)==NULL){
			printf("No se pudo leer la entrada\n");
			exit(1);
		}
		vector1[i]= strtof(input,NULL);
		if(errno == ERANGE){
			printf("Error:numero fuera del rango\n");
			exit(1);
		}
		vector2[i]= strtof(input,NULL);
		if(errno == ERANGE){
			printf("Error:numero fuera del rango\n");
			exit(1);
		}
	}
}
void printvectores(float *vector1,float *vector2,int cantidad){
	printf("\nVector1: ");
	printf("(");
	for(int i=0;i<cantidad;++i){
		printf("%.2f,", vector1[i]);
	}

	printf(")\n");

	printf("\nVector2: ");
	printf("(");
	for(int i=0;i<cantidad;++i){
		printf("%.2f,", vector2[i]);
	}

	printf(")\n");
}

void sumavectores(float *vectorresultante, const float *vector1, const float *vector2,const int cantidad){
for(int i=0; i<cantidad; ++i){
	vectorresultante[i] = vector1[i] + vector2[i];
}
printf("\nEl resultado de tu vector es: ");
printf("(");
for(int i=0;i<cantidad;++i){
	printf("%.2f,", vectorresultante[i]);
}

printf(")\n");
}

void restavectores(float *vectorresultante, const float *vector1, const float *vector2,const int cantidad){
for(int i=0; i<cantidad; ++i){
	vectorresultante[i] = vector1[i] - vector2[i];
}
printf("\nEl resultado de restar vector1 y vector 2 es: ");
printf("(");
for(int i=0;i<cantidad;++i){
	printf("%.2f,", vectorresultante[i]);
}

printf(")\n");

for(int i=0; i<cantidad; ++i){
	vectorresultante[i] = vector2[i] - vector1[i];
}
printf("\nEl resultado de restar vector 2 y vector 1 es: ");
printf("(");
for(int i=0;i<cantidad;++i){
	printf("%.2f,", vectorresultante[i]);
}
printf(")\n");
}

void productoporunescalar(float *vectorresultante, const float *vector1, const float *vector2,const int cantidad){
	char input[10];
	float escalar;
	printf("Dame el valor del escalar por el que quieres multiplicar a los vectores\n");
	if(fgets(input,10,stdin)==NULL){
		printf("Error no se pudo leer la entrada\n");
		exit(1);
	}

		escalar=strtof(input, NULL);
		for(int i=0; i<cantidad; ++i){
			vectorresultante[i] = escalar * vector1[i];
		}
		printf("\nEl resultado de multiplicar el escalar por el vector 1 es: ");
		printf("(");
		for(int i=0;i<cantidad;++i){
			printf("%.2f,", vectorresultante[i]);
		}
		printf(")\n");

		for(int i=0; i<cantidad; ++i){
			vectorresultante[i] = escalar * vector2[i];
		}
		printf("\nEl resultado de multiplicar el escalar por el vector 2 es: ");
		printf("(");
		for(int i=0;i<cantidad;++i){
			printf("%.2f,", vectorresultante[i]);
		}
		printf(")\n");

}
 

float sumacomponentesvector(const float *vector, int cantidad){
	float suma = 0;
	for(int i=0; i<cantidad; ++i){
		suma+=vector[i];
	}
	return suma;
}

void normadelvector(const float *vector1, const float *vector2, int cantidad){
     float *nuevovector1 = (float*)calloc(cantidad, sizeof(float));
     float *nuevovector2 = (float*)calloc(cantidad, sizeof(float));
      float sumavector1;
      float sumavector2;

     for (int i=0; i< cantidad; ++i){
     	nuevovector1[i] = vector1[i] * vector1[i];
     	nuevovector2[i] = vector2[i] * vector2[i];
     }
    sumavector1 = sumacomponentesvector(nuevovector1,cantidad);
    sumavector2 = sumacomponentesvector(nuevovector2,cantidad);
    printf("La norma del vector 1 es %.2f\n", sqrtf(sumavector1));
    printf("La norma del vector 1 es %.2f\n", sqrtf(sumavector2));
    free(nuevovector1);
    free(nuevovector2);
}

float productopunto(const float *vector1, const float *vector2, int cantidad){
	float suma = 0;
	for(int i=0; i<cantidad; ++i){
		suma+= vector1[i]*vector2[i];
	}
	return suma;

}
float sumavector(const float *vector,int cantidad){
	float suma = 0;
	for(int i=0; i<cantidad; ++i){
		suma+= vector[i];
	}
	return suma;
}

float normavector(const float *vector, int cantidad){
	float *newvector=(float*)calloc(cantidad,sizeof(float));
	float sumvector;
	for(int i=0; i<cantidad; ++i){
		newvector[i]=vector[i]*vector[i];
	}
	sumvector=sumavector(newvector,cantidad);
	return sqrtf(sumvector);
}





void angulovectores(float *vector1, float *vector2, int cantidad){
	float suma = productopunto(vector1, vector2, cantidad);
	float norma1 = normavector(vector1,cantidad);
	float norma2 = normavector(vector2,cantidad);
	float radianes = (suma/norma1*norma2);
	float resultado = acosf(radianes);
	double resultadoengrados = resultado *(180/M_PI);
	printf("El Angulo entre los vectores en radianes es %2.f\n",radianes);
	printf("El Angulo entre los vectores en grados es %2.f%c\n",resultadoengrados,167);

}

#endif//PROYECTOVECTORES_FUNCIONESVECTORES_H









	











